# Pink Planner Android – Test report (honest status)

Environment used: Node 22 only. **No Android SDK, no `javac`, no emulator, no device, network blocked → `android/` was never generated and the APK was never built or run.**
“PASS (mock)” = logic verified in Node against *mocked* Capacitor plugins (`tools/mock_test.js`, 25 checks). It proves my
code calls the plugins correctly; it does **not** prove Android behaves as expected.

| Feature | Result | Notes |
|---|---|---|
| JavaScript syntax of generated `www/index.html` | PASS | `node --check` |
| Patch script (permissions, icons, splash, sound), idempotent | PASS (simulated android/ folder) | real `cap add android` output not available |
| Icons/splash generated and visually inspected (launcher, notification) | PASS | notification icon had edge clipping → fixed |
| Reminder scheduled at start − N minutes in local time, unique ids | PASS (mock) | |
| No duplicates on re-save / resync / repeated resync | PASS (mock) | |
| Edit replaces old reminder; delete/complete/off cancels | PASS (mock) | delete path = same cancel call |
| Past reminders never scheduled; notifications-off cancels all | PASS (mock) | |
| Channel per mode (sound/vibration/both/silent), silent sound for vibration-only | PASS (mock) | real channel behaviour unverified |
| Calendar: create once, update on edit, adopt existing (no duplicate), pull external edit/delete, delete | PASS (mock) | method names, option names, string ids and ms timestamps now **checked against the plugin’s published API docs (v8)**; behaviour on a real phone UNVERIFIED |
| Plugin versions / Capacitor line | FIXED | earlier `^6` pins were wrong (calendar plugin has no Cap 6 line); now Capacitor 8 + `@ebarooni/capacitor-calendar@^8.6.0`. Exact resolved versions UNVERIFIED (npm unreachable) |
| Calendar plugin native name (`CapacitorCalendar` vs `EBarooniCapacitorCalendar`) | PASS (mock fallback) | real name UNVERIFIED |
| Notification API names (schedule/getPending/cancel/createChannel/check+requestPermissions/check+changeExactNotificationSetting, `allowWhileIdle`) | VERIFIED against docs | |
| Boot-restore receiver / permissions in merged manifest | NOT YET VERIFIED | docs & Capacitor history show a BOOT_COMPLETED restore receiver; `verify_apk.sh` will check the real APK in CI |
| Generate `android/` project (`npx cap add android`) | NOT DONE | network blocked in this sandbox |
| Debug APK build / emulator smoke test | NOT DONE | no Android SDK/javac/network here; CI jobs written but never run |
| Backup export/restore round-trip | restore PASS (mock); export UNVERIFIED | |
| Task persistence (Preferences) | PASS (mock) | survives restart/update: UNVERIFIED on device |
| Day rollover / time-zone / DST detection code | UNVERIFIED | only logic carried over from web version |
| Notifications when app closed, phone locked, after reboot | **UNVERIFIED** | rely on Android AlarmManager + plugin boot receiver |
| Real sound / vibration / Do Not Disturb behaviour | **UNVERIFIED** | |
| Android permission dialogs (notifications, exact alarm, calendar) | **UNVERIFIED** | |
| Reading/adding/editing/deleting events in the phone’s calendar | **UNVERIFIED** | |
| 12/24-hour “device default” | UNVERIFIED | Android WebView follows locale, not always the phone’s 24-hour switch |
| All six themes on device, status-bar colour, splash, back button | UNVERIFIED | |
| Different screen sizes, edge-to-edge/notch | UNVERIFIED | |
| Release APK | NOT BUILT | |

Problems found while testing: notification icon clipped (fixed); my own test snapshot bug (fixed); no other defects found —
which says little until it runs on a real phone. First things to check after installing: Settings → *Send test*, a task with a
1-minute reminder with the app swiped away, then reboot.
