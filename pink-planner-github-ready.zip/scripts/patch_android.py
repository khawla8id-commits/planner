#!/usr/bin/env python3
"""Run once after `npx cap add android`: permissions, icons, splash, notification icon, silent sound."""
import pathlib, re, shutil, sys
root = pathlib.Path(__file__).resolve().parent.parent
app = root / "android/app/src/main"
if not app.exists(): sys.exit("android/ not found - run `npx cap add android` first")
man = app / "AndroidManifest.xml"; x = man.read_text()
perms = ["POST_NOTIFICATIONS","SCHEDULE_EXACT_ALARM","USE_EXACT_ALARM","RECEIVE_BOOT_COMPLETED","VIBRATE","WAKE_LOCK","READ_CALENDAR","WRITE_CALENDAR"]
add = "".join(f'    <uses-permission android:name="android.permission.{p}" />\n' for p in perms if f"android.permission.{p}\"" not in x)
x = x.replace("</manifest>", add + "</manifest>"); man.write_text(x)
res = app / "res"
for d in res.glob("drawable*"):
    for f in d.glob("splash.png"): f.unlink()
shutil.copytree(root / "resources/res", res, dirs_exist_ok=True)
for f in list(res.glob("drawable*/ic_launcher_foreground.xml"))+list(res.glob("drawable*/ic_launcher_background.xml")): f.unlink()
for f in res.glob("mipmap-*/ic_launcher_foreground.webp"): f.unlink()
for f in res.glob("mipmap-*/ic_launcher*.webp"): f.unlink()
print("Android project patched: permissions + icons + splash + sounds")
