#!/usr/bin/env bash
# Fails if the built APK lacks required permissions / receivers. Uses SDK tools (apkanalyzer).
set -e
APK=${1:-android/app/build/outputs/apk/debug/app-debug.apk}
AA=$(command -v apkanalyzer || ls "$ANDROID_HOME"/cmdline-tools/*/bin/apkanalyzer | head -1)
M=$("$AA" manifest print "$APK"); echo "$M" > build-manifest.xml
fail=0
for p in POST_NOTIFICATIONS SCHEDULE_EXACT_ALARM USE_EXACT_ALARM RECEIVE_BOOT_COMPLETED VIBRATE READ_CALENDAR WRITE_CALENDAR; do
  echo "$M" | grep -q "android.permission.$p" && echo "OK   permission $p" || { echo "FAIL permission $p"; fail=1; }
done
for r in LocalNotificationRestoreReceiver TimedNotificationPublisher; do
  echo "$M" | grep -q "$r" && echo "OK   component  $r" || { echo "FAIL component  $r"; fail=1; }
done
echo "$M" | grep -q 'android.intent.action.BOOT_COMPLETED' && echo "OK   BOOT_COMPLETED receiver" || { echo "FAIL BOOT_COMPLETED receiver"; fail=1; }
echo "$M" | grep -q 'package="com.pinkplanner.app"' && echo "OK   package id" || { echo "FAIL package id"; fail=1; }
"$AA" apk summary "$APK" || true
exit $fail
