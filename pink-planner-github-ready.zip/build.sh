#!/usr/bin/env bash
# Needs: Node 22+, JDK 21, Android SDK (ANDROID_HOME), Python 3.  Output: android/app/build/outputs/apk/debug/app-debug.apk
set -e
npm install
[ -d android ] || npx cap add android
python3 scripts/patch_android.py
npx cap sync android
(cd android && chmod +x gradlew && ./gradlew assembleDebug)
./scripts/verify_apk.sh
echo "APK: $(pwd)/android/app/build/outputs/apk/debug/app-debug.apk"
