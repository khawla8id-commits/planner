// Logic tests of the native layer against MOCK Capacitor plugins (NOT a real device).
const fs=require('fs');const src=fs.readFileSync('/tmp/www.js','utf8');
const el=()=>({classList:{add(){},remove(){},toggle(){},contains:()=>false},style:{},dataset:{},addEventListener(){},appendChild(){},setAttribute(){},click(){}});
const store={};let pending=new Map(),cal=new Map(),calId=500,channels=[],log=[];
const pad=x=>String(x).padStart(2,'0');
const P={
 Preferences:{async get({key}){return{value:store[key]??null}},async set({key,value}){store[key]=value}},
 LocalNotifications:{async createChannel(o){channels.push(o)},async checkPermissions(){return{display:'granted'}},async requestPermissions(){return{display:'granted'}},async checkExactNotificationSetting(){return{exact_alarm:'granted'}},
  async schedule({notifications}){notifications.forEach(n=>{if(!(n.schedule.at instanceof Date))throw new Error('bad at');pending.set(n.id,n)})},async cancel({notifications}){notifications.forEach(n=>pending.delete(n.id))},async getPending(){return{notifications:[...pending.values()].map(n=>({id:n.id}))}}},
 CapacitorCalendar:{async requestFullCalendarAccess(){return{result:'granted'}},async listCalendars(){return{result:[{id:'1',title:'Personal'}]}},async getDefaultCalendar(o){if(!o||o.useFallbackCalendar!==true)throw new Error('opts');return{result:{id:'1',title:'Personal'}}},
  async createEvent(o){const id=String(++calId);cal.set(id,{id,...o});return{id}},async modifyEvent(o){if(!cal.has(String(o.id)))throw new Error('nf');Object.assign(cal.get(String(o.id)),o)},async deleteEvent({id}){if(typeof id!=='string')throw new Error('id must be string');cal.delete(String(id))},
  async listEventsInRange({from,to}){return{result:[...cal.values()].filter(e=>e.startDate>=from&&e.startDate<=to)}}},
 App:{addListener(n,f){log.push(n)}},SplashScreen:{hide(){log.push('splash')}},SystemBars:{async setStyle(o){log.push('style:'+o.style)}}};
const unimpl=new Proxy({},{get:()=>async()=>{throw new Error('"CapacitorCalendar" plugin is not implemented on android')}});
const reg={};P.EBarooniCapacitorCalendar=P.CapacitorCalendar;P.CapacitorCalendar=unimpl; // simulate: first plugin name NOT registered, second is
global.window={Capacitor:{isNativePlatform:()=>true,registerPlugin:n=>{reg[n]=1;return P[n]||unimpl}},addEventListener(){}};
global.document={querySelector:()=>el(),querySelectorAll:()=>[],addEventListener(){},documentElement:el(),head:el(),body:el(),createElement:el};
global.getComputedStyle=()=>({getPropertyValue:()=>'#fff0f6'});global.confirm=()=>true;global.navigator={vibrate(){}};
global.setInterval=()=>0;global.setTimeout=(f)=>0;global.clearTimeout=()=>0;global.localStorage={getItem:()=>null,setItem(){}};
let T;window.__PP_TEST__=o=>{T=o};
let ok=0,bad=0;const t=(n,c)=>{c?ok++:(bad++,console.log('FAIL',n))};
const fut=(min)=>{const d=new Date(Date.now()+min*6e4);return{date:d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate()),start:pad(d.getHours())+':'+pad(d.getMinutes())}};
const S0=()=>T.S,S=S0;
(async()=>{
 new Function(src)();await new Promise(r=>setTimeout?setImmediate(r):r());await new Promise(r=>setImmediate(r));
 t('4 channels created',channels.length===4&&channels.some(c=>c.sound==='pp_silent.wav'&&c.vibration));
 t('calendar plugin name fallback works (2nd name picked)',reg.EBarooniCapacitorCalendar===1&&S0().set.calId==='1');
 t('system bars styled for theme',log.includes('style:LIGHT'));
 t('splash hidden after boot',log.includes('splash')&&log.includes('backButton'));
 const f=fut(90);
 const mk=(id,x)=>({id,title:'Task '+id,desc:'desc '+id,date:f.date,start:f.start,end:'23:59',cat:'Other',pri:'Low',done:false,remind:true,mins:10,...x});
 S().tasks.push(mk('a'),mk('b',{mins:30}));await T.afterSave(S().tasks[0]);await T.afterSave(S().tasks[1]);
 t('2 reminders scheduled, unique ids',pending.size===2&&new Set([...pending.keys()]).size===2);
 const n=pending.get(S().tasks[0].nid);const exp=new Date(f.date+'T'+f.start).getTime()-10*6e4;
 t('fires exactly mins before start (local time)',n.schedule.at.getTime()===exp);
 t('body has description+time, uses channel+icon',/desc a/.test(n.body)&&/🕒/.test(n.body)&&n.channelId==='pp_both'&&n.smallIcon==='ic_stat_bow'&&n.schedule.allowWhileIdle);
 await T.afterSave(S().tasks[0]);await T.afterSave(S().tasks[0]);t('re-saving does not duplicate',pending.size===2);
 S().tasks[0].mins=20;await T.afterSave(S().tasks[0]);t('edit replaces old time',pending.size===2&&pending.get(S().tasks[0].nid).schedule.at.getTime()===exp-10*6e4);
 S().tasks[0].done=true;await T.syncOne(S().tasks[0]);t('completing cancels reminder',pending.size===1);
 S().tasks[0].done=false;await T.syncOne(S().tasks[0]);t('un-completing restores',pending.size===2);
 S().tasks[1].remind=false;await T.afterSave(S().tasks[1]);t('reminder off cancels',pending.size===1);
 S().tasks[1].remind=true;S().set.notif='silent';await T.resyncAll();t('resyncAll: no dupes, new channel',pending.size===2&&[...pending.values()].every(x=>x.channelId==='pp_silent'));
 S().set.on=false;await T.resyncAll();t('notifications disabled cancels all',pending.size===0);S().set.on=true;S().set.notif='both';
 const past=mk('p',{date:'2020-01-01'});S().tasks.push(past);await T.resyncAll();t('past reminders never scheduled',![...pending.values()].some(x=>x.id===past.nid));
 await T.resyncAll();await T.resyncAll();t('repeated resync stable',pending.size===2);
 // calendar
 await T.calToggle('a');const a=S().tasks[0];t('event created once with correct times',cal.size===1&&a.calEv&&cal.get(a.calEv).startDate===new Date(a.date+'T'+a.start).getTime());
 await T.afterSave(a);t('edit updates, no duplicate event',cal.size===1);
 a.calEv='';await T.calToggle('a');t('re-add adopts existing event (no dup)',cal.size===1&&a.calEv);
 const e=cal.get(a.calEv);e.startDate+=3600e3;e.endDate+=3600e3;e.title='Moved!';await T.calPull();t('external calendar edit pulled into task',a.title==='Moved!'&&a.start===(pad(new Date(e.startDate).getHours())+':'+pad(new Date(e.startDate).getMinutes())));
 t('...and reminder rescheduled',pending.get(a.nid).schedule.at.getTime()===new Date(a.date+'T'+a.start).getTime()-20*6e4);
 cal.delete(a.calEv);await T.calPull();t('external delete unlinks task',a.calEv==='');
 await T.calToggle('a');const id=a.calEv;await T.calDelete(id);a.calEv='';t('delete from calendar works',!cal.has(id));
 // persistence
 const saved=JSON.parse(store.pinkplanner);t('tasks persisted to native Preferences',saved.tasks.length===S().tasks.length&&saved.set.theme==='pink');
 // backup roundtrip
 const snap=JSON.stringify({app:'pink-planner',v:1,S:S()});global.FileReader=class{readAsText(){this.result=snap;this.onload()}};
 const before=S().tasks.length;S().tasks.length=0;await T.importB({});await new Promise(r=>setImmediate(r));await new Promise(r=>setImmediate(r));t('backup restore brings tasks back',T.S.tasks.length===before);
 console.log(ok,'passed',bad,'failed');
})().catch(e=>{console.log('CRASH',e);process.exit(1)});
