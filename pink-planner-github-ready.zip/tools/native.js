/* ===== Native Android layer (Capacitor) ===== */
let NS={n:'unknown',x:'unknown',c:'unknown'},CALS=[],EV={};
const CH={sound:['pp_sound','Sound reminders',4,false,null],vibration:['pp_vibe','Vibration reminders',4,true,'pp_silent.wav'],both:['pp_both','Sound + vibration reminders',4,true,null],silent:['pp_silent','Silent reminders',2,false,null]};
async function initChannels(){if(!LN)return;for(const k in CH){const[id,name,imp,vib,snd]=CH[k],o={id,name,description:'Pink Planner task reminders',importance:imp,vibration:vib,visibility:1,lights:true,lightColor:'#FF8FB8'};if(snd)o.sound=snd;try{await LN.createChannel(o)}catch(e){}}}
async function refreshNS(){if(!LN)return;try{NS.n=(await LN.checkPermissions()).display}catch(e){}try{NS.x=(await LN.checkExactNotificationSetting()).exact_alarm}catch(e){}}
async function ensurePerm(){if(!LN){toast('Reminders need the Android app 📱');return false}
try{let p=await LN.checkPermissions();if(p.display!=='granted')p=await LN.requestPermissions();await refreshNS();if(p.display!=='granted'){toast('Notifications are off — enable them in Android Settings 🔒');return false}
if(NS.x&&NS.x!=='granted')toast('Please allow “Alarms & reminders” so reminders arrive on time ⏰');return true}catch(e){toast('Couldn’t ask for notification permission');return false}}
/* Reminders: scheduled natively with AlarmManager through LocalNotifications (works when app is closed; plugin re-registers them after reboot) */
const nbody=t=>(t.desc?t.desc+'\n':'')+'🕒 '+tm(t.start)+'–'+tm(t.end)+' · '+dl(t.date);
const when=t=>new Date(new Date(t.date+'T'+t.start).getTime()-t.mins*6e4);
const eligible=t=>S.set.on&&t.remind&&!t.done&&when(t)>new Date();
const nObj=t=>({id:t.nid,title:'🎀 '+t.title,body:nbody(t),largeBody:nbody(t),summaryText:'Pink Planner',schedule:{at:when(t),allowWhileIdle:true},channelId:CH[S.set.notif][0],smallIcon:'ic_stat_bow',iconColor:'#FF8FB8',extra:{tid:t.id}});
function ensureNid(t){if(!t.nid){S.nid=(S.nid||1000)+1;t.nid=S.nid;save()}}
async function cancelN(t){if(LN&&t&&t.nid)try{await LN.cancel({notifications:[{id:t.nid}]})}catch(e){}}
async function schedule(t){if(!LN)return;ensureNid(t);await cancelN(t);if(!eligible(t))return;try{await LN.schedule({notifications:[nObj(t)]})}catch(e){toast('Couldn’t schedule the reminder 😢')}}
const syncOne=t=>schedule(t);
async function resyncAll(){if(!LN)return;try{const p=await LN.getPending(),ids=(p.notifications||[]).filter(n=>n.id>=1000).map(n=>({id:n.id}));if(ids.length)await LN.cancel({notifications:ids});S.tasks.forEach(ensureNid);const L=S.tasks.filter(eligible).map(nObj);if(L.length)await LN.schedule({notifications:L})}catch(e){}}
async function testN(){if(!await ensurePerm())return;try{await LN.schedule({notifications:[{id:1,title:'🎀 Test reminder',body:'Hi gorgeous! Your reminders work 💗',schedule:{at:new Date(Date.now()+5000),allowWhileIdle:true},channelId:CH[S.set.notif][0],smallIcon:'ic_stat_bow',iconColor:'#FF8FB8'}]});toast('Test reminder in 5 seconds — try closing the app! 🔔')}catch(e){toast('Couldn’t send the test reminder')}}
async function afterSave(t){if(!t)return;ensureNid(t);if(t.remind&&S.set.on)await ensurePerm();await schedule(t);if(t.calEv)await calUpdate(t)}
/* Calendar (Android Calendar Provider via @ebarooni/capacitor-calendar) */
const CAL_NAMES=['CapacitorCalendar','EBarooniCapacitorCalendar'];let calOK=false;
async function pickCal(){if(!NATIVE||calOK)return;for(const n of CAL_NAMES){const p=reg(n);try{await p.listCalendars();CAL=p;calOK=true;return}catch(e){const m=String((e&&(e.message||e.code))||e);if(!/unimplemented|not implemented|not available/i.test(m)){CAL=p;calOK=true;return}}}}
async function calAccess(ask){if(!NATIVE){if(ask)toast('Calendar needs the Android app 📱');return false}
try{await pickCal();if(ask)await CAL.requestFullCalendarAccess();CALS=(await CAL.listCalendars()).result||[];NS.c='granted';
if(!S.set.calId||!CALS.some(c=>String(c.id)===String(S.set.calId))){let d=null;try{d=(await CAL.getDefaultCalendar({useFallbackCalendar:true})).result}catch(e){}const c=d||CALS[0];if(c){S.set.calId=String(c.id);save()}}return true}
catch(e){NS.c='denied';if(ask)toast('Calendar access was not granted. Pink Planner works fine without it 💗');return false}}
const hm=ms=>{const d=new Date(ms);return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')};
const st_=t=>new Date(t.date+'T'+t.start).getTime(),en_=t=>new Date(t.date+'T'+t.end).getTime();
const calOpts=t=>({title:t.title,startDate:st_(t),endDate:en_(t),description:(t.desc?t.desc+'\n\n':'')+'Added by Pink Planner 🎀',isAllDay:false});
async function calToggle(id){const t=S.tasks.find(x=>x.id===id);if(!t)return;
if(t.calEv){if(confirm('Remove this task from your phone calendar?')){await calDelete(t.calEv);t.calEv='';save();render();toast('Removed from calendar')}return}
if(!await calAccess(true))return;
try{let evs=[];try{evs=(await CAL.listEventsInRange({from:st_(t)-1,to:en_(t)+1})).result||[]}catch(e){}
const dup=evs.find(e=>e.title===t.title&&+e.startDate===st_(t));let eid;
if(dup)eid=dup.id;else{const o=calOpts(t);if(S.set.calId)o.calendarId=S.set.calId;const r=await CAL.createEvent(o);if(!r||!r.id)throw new Error('no id');eid=r.id}
t.calEv=String(eid);save();render();toast(dup?'Linked to the matching calendar event ✅':'Added to your phone calendar ✅')}catch(e){toast('Couldn’t add to the calendar 😢')}}
async function calUpdate(t){try{await CAL.modifyEvent({id:t.calEv,...calOpts(t)})}catch(e){t.calEv='';save()}}
async function calDelete(id){try{await CAL.deleteEvent({id:String(id)})}catch(e){}}
async function calPull(){if(NS.c!=='granted'||!CAL)return;const L=S.tasks.filter(t=>t.calEv);if(!L.length)return;const ts=L.map(t=>st_(t)),Y=365*864e5;let evs=[];
try{evs=(await CAL.listEventsInRange({from:Math.min(...ts)-Y,to:Math.max(...ts)+Y})).result||[]}catch(e){return}
let ch=false;for(const t of L){const e=evs.find(x=>String(x.id)===String(t.calEv));if(!e){t.calEv='';ch=true;continue}if(e.isAllDay)continue;
const nd=ds(new Date(+e.startDate)),ns=hm(+e.startDate),ne=hm(+e.endDate);
if(e.title&&e.title!==t.title){t.title=e.title;ch=true}if(nd!==t.date||ns!==t.start||(ne!==t.end&&ne>ns)){t.date=nd;t.start=ns;if(ne>ns)t.end=ne;ch=true}}
if(ch){save();await resyncAll();render()}}
async function loadEv(d){if(NS.c!=='granted'||!S.set.showCal){EV[d]=[];return}try{const a=pd(d).getTime();EV[d]=(await CAL.listEventsInRange({from:a,to:a+864e5-1})).result||[]}catch(e){EV[d]=[]}if(view==='cal'&&sel===d)render()}
function evHTML(){const mine=new Set(S.tasks.map(t=>String(t.calEv)));const L=(EV[sel]||[]).filter(e=>!mine.has(String(e.id)));if(!L.length)return'';
return'<h2>📆 On your phone calendar</h2>'+L.map(e=>`<div class="card ev"><b>${esc(e.title||'(no title)')}</b><div class="meta"><span>${e.isAllDay?'All day':new Date(+e.startDate).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})}</span><span class="chip">Phone calendar</span></div></div>`).join('')}
/* Backup / restore */
async function exportB(){try{const data=JSON.stringify({app:'pink-planner',v:1,at:new Date().toISOString(),S},null,1),w=await PL.Filesystem.writeFile({path:'pink-planner-backup-'+today()+'.json',data,directory:'CACHE',encoding:'utf8'});await PL.Share.share({title:'Pink Planner backup',url:w.uri})}catch(e){toast('Backup could not be created 😢')}}
function importB(file){const r=new FileReader();r.onload=async()=>{try{const o=JSON.parse(r.result);if(o.app!=='pink-planner'||!o.S||!Array.isArray(o.S.tasks))throw 0;if(!confirm('Replace everything with this backup ('+o.S.tasks.length+' tasks)?'))return;
for(const t of S.tasks)await cancelN(t);S={tasks:o.S.tasks,fired:{},nid:o.S.nid||1000,set:{...DEF,...o.S.set}};if(!THEMES.includes(S.set.theme))S.set.theme='pink';save();await resyncAll();render();toast('Backup restored 🩷')}catch(e){toast('That file is not a Pink Planner backup')}};r.readAsText(file)}
async function boot(){try{render();clk();await initChannels();await refreshNS();await calAccess(false);await resyncAll();calPull();loadEv(sel);
if(PL.App){PL.App.addListener('backButton',()=>{if($('#ov').classList.contains('on'))$('#ov').classList.remove('on');else if(view!=='home'){view='home';render()}else PL.App.exitApp()});
PL.App.addListener('appStateChange',async s=>{if(s.isActive){await refreshNS();await calAccess(false);await resyncAll();await calPull();loadEv(sel);render()}})}}finally{if(PL.SplashScreen)PL.SplashScreen.hide()}}
