# Generates launcher icon, adaptive icon, notification icon, splash and silent sound. Needs Pillow.
import math, os, wave
from PIL import Image, ImageDraw
R='resources/res'
def bow(sz, fg, hi=None, bg=None, scale=1.0, circle=False):
    S=sz*4; im=Image.new('RGBA',(S,S),(0,0,0,0)); d=ImageDraw.Draw(im)
    if bg:
        if circle: d.ellipse([0,0,S-1,S-1],fill=bg)
        else: d.rounded_rectangle([0,0,S-1,S-1],radius=S//5,fill=bg)
    cx,cy,r=S/2,S/2,S*0.17*scale
    def loop(sign):
        pts=[]
        for i in range(120):
            a=2*math.pi*i/120; x=1.55*r*math.cos(a); y=0.95*r*math.sin(a)
            t=math.radians(-18*sign); xr=x*math.cos(t)-y*math.sin(t); yr=x*math.sin(t)+y*math.cos(t)
            pts.append((cx+sign*1.25*r+xr, cy-0.15*r+yr))
        return pts
    for sg in(-1,1): d.polygon([(cx+sg*0.1*r,cy+0.2*r),(cx+sg*1.35*r,cy+2.1*r),(cx+sg*0.35*r,cy+2.25*r),(cx-sg*0.2*r,cy+0.9*r)],fill=fg)
    for sg in(-1,1): d.polygon(loop(sg),fill=fg)
    if hi:
        for sg in(-1,1):
            pts=[(cx+sg*1.25*r+(x-(cx+sg*1.25*r))*0.55,cy-0.15*r+(y-(cy-0.15*r))*0.55) for x,y in loop(sg)]
            d.polygon(pts,fill=hi)
    d.ellipse([cx-0.62*r,cy-0.62*r-0.1*r,cx+0.62*r,cy+0.62*r-0.1*r],fill=fg)
    return im.resize((sz,sz),Image.LANCZOS)
def save(im,path):
    os.makedirs(os.path.dirname(path),exist_ok=True); im.save(path)
dens={'mdpi':1,'hdpi':1.5,'xhdpi':2,'xxhdpi':3,'xxxhdpi':4}
for n,m in dens.items():
    s=round(48*m); save(bow(s,'#FF6FA3','#FFC2DC','#FFE4EF'),f'{R}/mipmap-{n}/ic_launcher.png')
    save(bow(s,'#FF6FA3','#FFC2DC','#FFE4EF',circle=True),f'{R}/mipmap-{n}/ic_launcher_round.png')
    s=round(108*m); save(bow(s,'#FF6FA3','#FFC2DC',None,scale=0.62),f'{R}/mipmap-{n}/ic_launcher_foreground.png')
    s=round(24*m); save(bow(s,'#FFFFFF',None,None,scale=0.95),f'{R}/drawable-{n}/ic_stat_bow.png')
# splash
sp=Image.new('RGBA',(1080,1920),'#FFD3E4'); b=bow(560,'#FF6FA3','#FFC2DC',None,scale=1.3); sp.alpha_composite(b,(260,680)); save(sp.convert('RGB'),f'{R}/drawable/splash.png')
os.makedirs(f'{R}/raw',exist_ok=True)
w=wave.open(f'{R}/raw/pp_silent.wav','wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(8000); w.writeframes(b'\x00\x00'*4000); w.close()
os.makedirs(f'{R}/values',exist_ok=True)
open(f'{R}/values/ic_launcher_background.xml','w').write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#FFE4EF</color>\n</resources>\n')
print('icons ok')
