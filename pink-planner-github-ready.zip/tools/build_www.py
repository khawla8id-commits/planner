import re, pathlib
src=open('/mnt/user-data/uploads/Pink_Planner__.html',encoding='utf8').read()
nat=open('tools/native.js',encoding='utf8').read()
def sub(old,new,rx=False,flags=re.S):
    global src
    if rx:
        n=len(re.findall(old,src,flags)); assert n==1,(old[:50],n); src=re.sub(old,lambda m:new,src,flags=flags)
    else:
        assert src.count(old)==1,(old[:60],src.count(old)); src=src.replace(old,new)
# 1 storage -> native Preferences (SharedPreferences), wrap script so it can await
sub("<script>\n","<script>\n(async()=>{\n")
sub("const DEF={name:'',notif:'both',fmt:'auto',theme:'pink',on:true};","""const NATIVE=!!(window.Capacitor&&window.Capacitor.isNativePlatform&&window.Capacitor.isNativePlatform()),RC={},reg=n=>RC[n]||(RC[n]=window.Capacitor.registerPlugin(n)),PL={};if(NATIVE)['LocalNotifications','Preferences','App','SplashScreen','Filesystem','Share','SystemBars'].forEach(n=>PL[n]=reg(n));
let CAL=NATIVE?reg('CapacitorCalendar'):undefined;const LN=PL.LocalNotifications,THEMES=['pink','burgundy','lavender','cream','pastel','dark'];
const kv={async get(k){if(PL.Preferences)return(await PL.Preferences.get({key:k})).value;return localStorage.getItem(k)},async set(k,v){if(PL.Preferences)await PL.Preferences.set({key:k,value:v});else localStorage.setItem(k,v)}};
const DEF={name:'',notif:'both',fmt:'auto',theme:'pink',on:true,calId:'',showCal:true};""")
sub("try{const r=JSON.parse(localStorage.getItem('pinkplanner')||'null');if(r)S={tasks:r.tasks||[],fired:r.fired||{},set:{...DEF,...r.set}}}catch(e){}",
    "try{const r=JSON.parse(await kv.get('pinkplanner')||'null');if(r)S={tasks:r.tasks||[],fired:{},nid:r.nid||1000,set:{...DEF,...r.set}}}catch(e){}")
sub("const save=()=>{try{localStorage.setItem('pinkplanner',JSON.stringify(S))}catch(e){}};","const save=()=>{kv.set('pinkplanner',JSON.stringify(S)).catch(()=>{})};")
# 2 remove JS reminder engine, insert native layer
sub(r"/\* Notifications \*/.*?window\.addEventListener\('focus',check\);",lambda:None or "", rx=True) if False else None
m=re.search(r"/\* Notifications \*/.*?window\.addEventListener\('focus',check\);",src,re.S); assert m
src=src[:m.start()]+nat+src[m.end():]
# 3 calendar replaces Google link
sub(r"function gcal\(t\).*\n","",rx=True,flags=0)
sub('data-a="gcal"','data-a="cal"')
sub(r"else if\(a==='gcal'\).*\n","else if(a==='cal')await calToggle(id);\n",rx=True,flags=0)
sub("else if(a==='pick'){sel=b.dataset.d;cd=pd(sel);render()}","else if(a==='pick'){sel=b.dataset.d;cd=pd(sel);render();loadEv(sel)}")
sub("${list(S.tasks.filter(t=>t.date===sel))}`},","${list(S.tasks.filter(t=>t.date===sel))}${evHTML()}`},")
# 4 task hooks
sub("if(t.remind&&S.set.on)ensurePerm()}","afterSave(id?S.tasks.find(x=>x.id===id):S.tasks[S.tasks.length-1])}")
sub("{S.tasks=S.tasks.filter(t=>t.id!==id);save();render()}","{const dt=S.tasks.find(t=>t.id===id);if(dt){cancelN(dt);if(dt.calEv)calDelete(dt.calEv)}S.tasks=S.tasks.filter(t=>t.id!==id);save();render()}")
sub("t.done=!t.done;save();","t.done=!t.done;save();syncOne(t);")
# 5 actions + settings
sub(r"else if\(a==='perm'\)await ensurePerm\(\);\nelse if\(a==='test'\)\{[^\n]*\}\}\);",
"""else if(a==='perm'){await ensurePerm();render()}
else if(a==='exact'){try{await LN.changeExactNotificationSetting()}catch(e){toast('Open Settings → Apps → Pink Planner → Alarms & reminders')}setTimeout(async()=>{await refreshNS();render()},1500)}
else if(a==='test')await testN();
else if(a==='calperm'){await calAccess(true);await loadEv(sel);render()}
else if(a==='export')await exportB();
else if(a==='import')$('#bk').click();});
document.addEventListener('change',e=>{if(e.target.id==='bk'&&e.target.files[0]){importB(e.target.files[0]);e.target.value=''}});""",rx=True,flags=0)
sub("ns='Notification'in window?Notification.permission:'unsupported'","ns=NS.n")
sub(r'<p class="note">Permission status:.*?Send test ✨</button></div>',
 '''<p class="note">Notifications: <b>${ns}</b> · Exact alarms: <b>${NS.x}</b></p><div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap"><button class="btn" data-a="perm">Allow notifications 🔔</button><button class="btn g" data-a="exact">Exact alarms ⏰</button><button class="btn g" data-a="test">Send test ✨</button></div>''',rx=True)
sub(r'<div class="card note"><b>💡 About reminders</b>.*?</div>',
 '''<div class="card"><b class="script">Phone calendar 📅</b><p class="note">Status: <b>${NS.c==='granted'?'connected':'not connected'}</b></p><button class="btn" data-a="calperm">Connect calendar 📅</button>${CALS.length?`<label>Add my tasks to</label><select data-s="calId">${CALS.map(c=>`<option value="${esc(c.id)}" ${String(c.id)===String(s.calId)?'selected':''}>${esc(c.title||c.name||c.id)}</option>`).join('')}</select><label class="sw"><input type="checkbox" data-s="showCal" ${s.showCal?'checked':''}>Show phone events in my calendar</label>`:''}</div>
<div class="card"><b class="script">Backup 💾</b><p class="note">Tasks live on this phone. Export a backup file to keep it safe, or restore one.</p><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" data-a="export">Export backup</button><button class="btn g" data-a="import">Restore backup</button></div><input type="file" id="bk" accept=".json,application/json" hidden></div>
<div class="card note"><b>💡 About reminders</b><br>Reminders are scheduled with Android’s alarm system, so they arrive even when Pink Planner is closed or the phone is locked, and are restored after a restart. Sound, vibration and Do Not Disturb follow your phone’s settings; you can fine-tune them in Android Settings → Apps → Pink Planner → Notifications.</div>''',rx=True)
sub("if(k==='on'&&S.set.on)ensurePerm();","if(k==='on'||k==='notif'||k==='fmt')resyncAll();if(k==='on'&&S.set.on)ensurePerm();if(k==='showCal')loadEv(sel);")
# 6 clock loop is UI only; reminders no longer depend on it
sub("lastDay=d;cd=new Date();render();","lastDay=d;cd=new Date();render();resyncAll();loadEv(sel);")
sub("lastTz=z;render();","lastTz=z;render();resyncAll();")
sub("clk();check()}","clk()}")
sub("setInterval(sync,1000);render();clk();check();","setInterval(sync,1000);\nif(window.__PP_TEST__)window.__PP_TEST__({get S(){return S},schedule,cancelN,resyncAll,afterSave,calToggle,calPull,calUpdate,syncOne,calDelete,testN,ensurePerm,importB,exportB});\nawait boot();")
sub("</script></body></html>","})();\n</script></body></html>")
# 7 status bar follows theme; .ev style
sub("m.content=getComputedStyle(document.documentElement).getPropertyValue('--bg').trim()||'#fff0f6'}","m.content=getComputedStyle(document.documentElement).getPropertyValue('--bg').trim()||'#fff0f6';try{if(PL.SystemBars)PL.SystemBars.setStyle({style:['dark','burgundy'].includes(S.set.theme)?'DARK':'LIGHT'}).catch(()=>{})}catch(e){}}")
sub("</style></head>",".ev{border-left:6px dashed var(--lav);background:var(--cream)}\n</style></head>")
src=re.sub(r'env\(safe-area-inset-(top|bottom|left|right),0px\)',lambda m:'var(--safe-area-inset-%s,env(safe-area-inset-%s,0px))'%(m.group(1),m.group(1)),src)
pathlib.Path('www/index.html').write_text(src,encoding='utf8'); print('www/index.html',len(src),'bytes')
