# Pink Planner 🎀 – Android app (Capacitor)

The original Pink Planner (`www/index.html`) wrapped as a native Android app with:
native scheduled reminders (Capacitor Local Notifications / AlarmManager), Android Calendar Provider integration
(`@ebarooni/capacitor-calendar`), native on-device storage (SharedPreferences via Capacitor Preferences),
splash screen, status-bar theming, back-button handling, backup/restore, bow launcher + notification icons.

> **No APK is included and no `android/` folder has been generated.** The sandbox this was prepared in has no Android SDK, no
> `javac`, and its network is blocked (npm/Google servers unreachable), so `npx cap add android` and Gradle could not run. Build it with one of the two options below (about 5–10 minutes).

## Option A – no installs: build the APK on GitHub (free)
1. Create a new GitHub repository and upload everything in this folder (keep `.github/workflows/android.yml`).
2. Open the **Actions** tab → *Build Pink Planner APK* → **Run workflow**.
3. When it finishes, download the artifact **pink-planner-debug-apk** → `app-debug.apk`.
4. Copy it to your phone and open it (allow “Install unknown apps” for your file manager/browser).

## Option B – on your computer
Requirements: Node 22+, JDK 21, Android Studio (or command-line SDK with `ANDROID_HOME` set), Python 3.
```
./build.sh          # npm install, cap add android, patch, sync, gradle assembleDebug, verify merged manifest
```
APK: `android/app/build/outputs/apk/debug/app-debug.apk`. To open in Android Studio: `npx cap open android`.
Install over USB: `adb install -r android/app/build/outputs/apk/debug/app-debug.apk`.

## Release APK
```
keytool -genkey -v -keystore pinkplanner.jks -alias pink -keyalg RSA -keysize 2048 -validity 10000
cd android && ./gradlew assembleRelease     # then sign with apksigner / configure signingConfigs in app/build.gradle
```
Keep the keystore safe: updates must be signed with the same key.

## What `scripts/patch_android.py` does
Adds permissions to `AndroidManifest.xml` (POST_NOTIFICATIONS, SCHEDULE_EXACT_ALARM, USE_EXACT_ALARM, RECEIVE_BOOT_COMPLETED,
VIBRATE, WAKE_LOCK, READ_CALENDAR, WRITE_CALENDAR), installs the bow launcher icon (adaptive + legacy), the notification
icon `ic_stat_bow`, the splash image and a silent sound used for “vibration only”. The reboot receiver and alarm
receivers come from the Local Notifications plugin’s own manifest.

## Android version notes
- **Android 13+ (API 33):** notifications need the runtime permission (the app asks).
- **Android 12/13/14:** exact alarms need “Alarms & reminders”. The app declares `USE_EXACT_ALARM` (auto-granted on 13+ for
  alarm/calendar-type apps; Google Play may review this) and `SCHEDULE_EXACT_ALARM` (user can grant it in Settings →
  Apps → Pink Planner → Alarms & reminders; Settings → *Exact alarms ⏰* opens it).
- **Battery savers (Xiaomi, Huawei, Oppo, Samsung “sleeping apps”…):** may delay or kill alarms. Set Pink Planner to
  *Unrestricted* battery use and allow auto-start.
- **Channels:** Android fixes a channel’s sound/vibration once created. The app uses 4 channels (sound, vibration, both,
  silent); fine-tune any of them in Android Settings → Apps → Pink Planner → Notifications. Silent mode / Do Not Disturb are
  handled by Android.
- **Time zone change while the app is closed:** alarms keep their absolute time; they are recomputed from the task’s local
  time next time you open the app.
- The Google Fonts link needs internet; offline the app uses system fonts.

## Changes in this revision (checked against the plugins’ current documentation)
- **Capacitor 8** (Node 22, JDK 21, compile/target SDK 36). The calendar plugin no longer publishes a Capacitor 6 line, so the
  earlier `^6` pin was wrong. `@ebarooni/capacitor-calendar` `latest` = Capacitor 8; its `deleteEvent`/`modifyEvent`/`listEventsInRange`
  signatures match the code (ids are strings, dates are millisecond timestamps).
- Plugins are reached with `Capacitor.registerPlugin(name)` (no bundler needed). The calendar plugin name is probed
  (`CapacitorCalendar`, then `EBarooniCapacitorCalendar`).
- Edge-to-edge: Capacitor 8 draws web content behind the system bars. Safe areas use the `--safe-area-inset-*` variables injected by
  the built-in SystemBars plugin (fallback `env()`); bar icon colour follows the theme. (`StatusBar.setBackgroundColor` was removed.)
- Doze: per Capacitor’s docs, `allowWhileIdle` notifications can fire at most once per ~9 minutes per app while the phone is in
  deep sleep, so two reminders set for nearly the same minute may arrive a few minutes apart.
- CI (`.github/workflows/android.yml`): runs the mock tests, builds the debug APK, **fails if the merged manifest lacks the
  permissions or the boot-restore / timed-notification receivers** (`scripts/verify_apk.sh`), then installs the APK on an
  Android 34 emulator, launches it and fails on a crash. None of this has been executed yet.
