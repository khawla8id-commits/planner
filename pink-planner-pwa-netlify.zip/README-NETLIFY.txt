PINK PLANNER — NETLIFY PWA BUILD

1. Extract this ZIP.
2. Upload the CONTENTS of this folder to Netlify (Deploy manually / drag and drop).
   Make sure index.html, manifest.webmanifest, sw.js, and icons/ are at the published root.
3. Open the Netlify HTTPS site in Chrome on Android.
4. Refresh once, wait a few seconds, then Chrome menu (⋮) → Install app.
   If it still offers only "Create shortcut", close the tab, reopen the site, and try again.

This creates an installable PWA (web app). It is not an APK/native Android package.
Native Android features such as guaranteed background alarms still require building and installing the APK
from the separate Capacitor Android project.
